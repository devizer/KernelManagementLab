#!/bin/bash
DATE=`date +%Y-%m-%d-%H-%M-%S`
file=Universe.Curses-$DATE.7z
echo FILE is $file
7za a /ssd/BACKUPS/$file -m0=lzma -mx=9 -mfb=64 -md=32m -ms=on -xr!bin -xr!obj -xr!*.userprefs .

export MAILRC=~/.config/mysmtp/rc
echo -e "Here is Universe.Curses backup: $file

tags: BACKUPS-VIA-EMAIL" | mailx -v -A mygmail -s "Universe.Curses source (BACKUPS-VIA-GMAIL)" -a /ssd/BACKUPS/$file annivation@gmail.com

