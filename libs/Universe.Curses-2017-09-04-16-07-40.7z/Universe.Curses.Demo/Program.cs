﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace Universe.Curses.Demo
{
	class MainClass
	{
		public static void Main (string[] args)
		{
//			Console.WriteLine ("Hello World!");
//
//			for (int i = 0; i < 2; i++) {
//				Console.CursorLeft = 0;
//				Console.CursorTop = 3+i*6;
//
//				Console.WriteLine (DIGITS.ALL);
//			}
//
//			Dump_UnicodeChars ();
//			Dump_Degrees ();
			DumpBoxes1 ();

			Console.WriteLine ("Console Windows: {0} x {1}", Console.WindowWidth, Console.WindowHeight);
		}

		static void Dump_UnicodeChars()
		{
			int[] startFrom = new[] { 0, 0x2500 };
			string[] names = new[] { "unicode-chars.txt", "box-chars.txt" };
			for(int s = 0; s<startFrom.Length; s++)
			{
				using(FileStream fs = new FileStream(names[s], FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
				using (StreamWriter wr = new StreamWriter(fs, new UTF8Encoding(false)))
				{
					for (int i = startFrom[s]; i < 65535; i++) {
						if (i > startFrom[s] && (i % 8 == 0))
							wr.WriteLine ();

						wr.Write ("{0:X4}: {1}    ", i, (char)i);

					}
				}
			}

			Console.WriteLine ("\x00B0");

		}

		static void Dump_Degrees()
		{
			string[] words = new[] { "05°9876543210-", "°", "-", "", "1200*4" };
			foreach(string word in words) {
				var buf = DIGITS.CreateBuffer (word, Color.DarkYellow, Color.Black);

				Console.WriteLine ("WORD: '{0}'", word);
				Dump_a_ScreenBuffer (buf);
				Console.WriteLine ();
			}
		}

		static void DumpBoxes1()
		{
			ScreenBuffer buf = BOXES.CreateBox ("Temperature", new Size (21, 7), true, 2, Color.White, Color.Black);
			ScreenBuffer deg = DIGITS.CreateBuffer ("47°", Color.White, Color.Black);
			buf.Draw (new Position ((buf.Width - deg.Width) / 2, 3), deg);
			Dump_a_ScreenBuffer (buf, new Position(0,0));
			int w = buf.Width + 1;
			// Thread.Sleep (100);

			buf = BOXES.CreateBox ("CPU * Cores", new Size (25, 7), false, 2, Color.White, Color.Black);
			ScreenBuffer cpu = DIGITS.CreateBuffer ("1200*4", Color.White, Color.Black);
			buf.Draw (new Position ((buf.Width - cpu.Width) / 2, 3), cpu);
			Dump_a_ScreenBuffer (buf, new Position(w,0));
			w += buf.Width + 1;
			// Thread.Sleep (100);

			ScreenBuffer ddr = DIGITS.CreateBuffer ("672", Color.White, Color.Black);
			buf = BOXES.CreateBox ("DDR", new Size (ddr.Width + 4, 7), true, 2, Color.White, Color.Black);
			buf.Draw (new Position ((buf.Width - ddr.Width) / 2, 3), ddr);
			Dump_a_ScreenBuffer (buf, new Position(w,0));

		}


		static void Dump_a_ScreenBuffer(ScreenBuffer buf)
		{
			for (int i = 0; i < buf.Height; i++) {
				Console.Write ("[");
				for (int j = 0; j < buf.Width; j++) {
					Console.Write (buf [j, i].Char);
				}

				Console.WriteLine ("]");
			}
		}

		static void Dump_a_ScreenBuffer(ScreenBuffer buf, Position pos)
		{
			for (int i = 0; i < buf.Height; i++) {
				Console.CursorTop = pos.Y + i;
				Console.CursorLeft = pos.X;
				for (int j = 0; j < buf.Width; j++) {
					Console.Write (buf [j, i].Char);
				}

				Console.WriteLine ();
			}
		}

	}
}
