``` ini

BenchmarkDotNet=v0.11.5, OS=Windows 10.0.17763.615 (1809/October2018Update/Redstone5)
Intel Xeon CPU 2.30GHz, 1 CPU, 2 logical cores and 1 physical core
.NET Core SDK=2.2.301
  [Host] : .NET Core 2.2.6 (CoreCLR 4.6.27817.03, CoreFX 4.6.27818.02), 64bit RyuJIT
  Clr    : .NET Framework 4.7.2 (CLR 4.0.30319.42000), 64bit RyuJIT-v4.7.3416.0
  Core   : .NET Core 2.2.6 (CoreCLR 4.6.27817.03, CoreFX 4.6.27818.02), 64bit RyuJIT


```
|            Method |  Job | Runtime | ArraysCount | Minify |    Kind |       Mean |     Error |     StdDev |     Median | Ratio | RatioSD | Rank |   Gen 0 |  Gen 1 | Gen 2 | Allocated |
|------------------ |----- |-------- |------------ |------- |-------- |-----------:|----------:|-----------:|-----------:|------:|--------:|-----:|--------:|-------:|------:|----------:|
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |  **False** |    **List** |   **719.8 us** |  **8.630 us** |   **8.073 us** |   **718.6 us** |  **0.60** |    **0.01** |    **1** | **14.6484** | **4.8828** |     **-** |  **94.62 KB** |
|         Optimized |  Clr |     Clr |          20 |  False |    List |   849.3 us |  7.054 us |   5.507 us |   850.1 us |  0.71 |    0.01 |    2 | 22.4609 | 5.8594 |     - |  141.3 KB |
|           Default |  Clr |     Clr |          20 |  False |    List | 1,190.1 us | 23.184 us |  22.769 us | 1,184.9 us |  1.00 |    0.00 |    3 | 29.2969 | 9.7656 |     - | 181.18 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |  False |    List |   700.7 us | 10.024 us |   9.376 us |   699.1 us |  0.60 |    0.01 |    1 |  9.7656 | 2.9297 |     - |  64.51 KB |
|         Optimized | Core |    Core |          20 |  False |    List |   800.5 us | 15.293 us |  18.205 us |   800.2 us |  0.69 |    0.02 |    2 | 17.5781 | 5.8594 |     - | 111.59 KB |
|           Default | Core |    Core |          20 |  False |    List | 1,162.7 us | 19.412 us |  18.158 us | 1,165.7 us |  1.00 |    0.00 |    3 | 15.6250 | 3.9063 |     - |  97.42 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |  **False** |   **Array** |   **605.7 us** |  **8.357 us** |   **7.817 us** |   **604.9 us** |  **0.50** |    **0.01** |    **1** | **13.6719** | **2.9297** |     **-** |  **87.91 KB** |
|         Optimized |  Clr |     Clr |          20 |  False |   Array |   737.7 us |  5.493 us |   4.289 us |   738.5 us |  0.61 |    0.02 |    2 | 21.4844 | 3.9063 |     - | 134.88 KB |
|           Default |  Clr |     Clr |          20 |  False |   Array | 1,199.0 us | 23.156 us |  24.777 us | 1,189.0 us |  1.00 |    0.00 |    3 | 27.3438 | 7.8125 |     - | 174.31 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |  False |   Array |   420.7 us |  6.727 us |   6.292 us |   420.7 us |  0.42 |    0.01 |    1 |  9.7656 | 2.4414 |     - |  60.69 KB |
|         Optimized | Core |    Core |          20 |  False |   Array |   517.3 us |  9.139 us |   8.549 us |   515.4 us |  0.51 |    0.01 |    2 | 16.6016 | 3.9063 |     - | 107.87 KB |
|           Default | Core |    Core |          20 |  False |   Array | 1,007.5 us | 19.511 us |  18.251 us | 1,006.2 us |  1.00 |    0.00 |    3 | 13.6719 | 3.9063 |     - |  93.52 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |  **False** |  **ROList** |   **815.6 us** | **12.705 us** |  **11.262 us** |   **815.4 us** |  **0.64** |    **0.01** |    **1** | **15.6250** | **4.8828** |     **-** |  **98.65 KB** |
|         Optimized |  Clr |     Clr |          20 |  False |  ROList |   974.5 us | 11.065 us |  10.350 us |   975.5 us |  0.76 |    0.01 |    2 | 23.4375 | 7.8125 |     - | 145.91 KB |
|           Default |  Clr |     Clr |          20 |  False |  ROList | 1,280.6 us | 20.709 us |  19.372 us | 1,280.1 us |  1.00 |    0.00 |    3 | 29.2969 | 9.7656 |     - | 184.53 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |  False |  ROList | 1,211.2 us | 14.333 us |  13.407 us | 1,207.7 us |  0.72 |    0.01 |    1 | 11.7188 | 3.9063 |     - |   75.5 KB |
|         Optimized | Core |    Core |          20 |  False |  ROList | 1,313.4 us | 20.717 us |  19.379 us | 1,313.0 us |  0.78 |    0.02 |    2 | 19.5313 | 5.8594 |     - | 122.64 KB |
|           Default | Core |    Core |          20 |  False |  ROList | 1,683.1 us | 22.393 us |  20.947 us | 1,681.7 us |  1.00 |    0.00 |    3 | 15.6250 | 5.8594 |     - | 107.47 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |  **False** | **ROArray** |   **755.9 us** | **14.959 us** |  **15.361 us** |   **756.4 us** |  **0.63** |    **0.02** |    **1** | **15.6250** | **5.8594** |     **-** | **101.64 KB** |
|         Optimized |  Clr |     Clr |          20 |  False | ROArray |   874.1 us |  8.148 us |   6.804 us |   874.5 us |  0.73 |    0.02 |    2 | 23.4375 | 7.8125 |     - | 149.02 KB |
|           Default |  Clr |     Clr |          20 |  False | ROArray | 1,193.6 us | 23.603 us |  27.182 us | 1,183.3 us |  1.00 |    0.00 |    3 | 29.2969 | 9.7656 |     - | 187.65 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |  False | ROArray | 1,099.2 us | 20.031 us |  18.737 us | 1,094.4 us |  0.69 |    0.02 |    1 | 11.7188 | 3.9063 |     - |  78.93 KB |
|         Optimized | Core |    Core |          20 |  False | ROArray | 1,185.5 us | 20.594 us |  19.263 us | 1,183.2 us |  0.75 |    0.02 |    2 | 19.5313 | 5.8594 |     - | 126.26 KB |
|           Default | Core |    Core |          20 |  False | ROArray | 1,584.7 us | 23.155 us |  21.659 us | 1,587.1 us |  1.00 |    0.00 |    3 | 17.5781 | 7.8125 |     - | 111.18 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |   **True** |    **List** |   **719.2 us** |  **6.028 us** |   **5.638 us** |   **721.2 us** |  **0.67** |    **0.01** |    **1** | **14.6484** | **4.8828** |     **-** |  **93.32 KB** |
|         Optimized |  Clr |     Clr |          20 |   True |    List |   842.2 us |  5.667 us |   4.732 us |   841.3 us |  0.78 |    0.01 |    2 | 22.4609 | 5.8594 |     - | 140.96 KB |
|           Default |  Clr |     Clr |          20 |   True |    List | 1,076.8 us | 17.579 us |  16.443 us | 1,079.1 us |  1.00 |    0.00 |    3 | 17.5781 | 5.8594 |     - | 118.29 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |   True |    List |   699.8 us | 10.122 us |   9.468 us |   701.0 us |  0.60 |    0.07 |    1 |  9.7656 | 2.9297 |     - |  64.06 KB |
|         Optimized | Core |    Core |          20 |   True |    List |   783.5 us |  9.424 us |   8.815 us |   782.9 us |  0.67 |    0.08 |    2 | 17.5781 | 4.8828 |     - | 111.23 KB |
|           Default | Core |    Core |          20 |   True |    List | 1,233.6 us | 72.191 us | 212.855 us | 1,102.9 us |  1.00 |    0.00 |    3 | 11.7188 | 3.9063 |     - |  81.29 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |   **True** |   **Array** |   **602.3 us** |  **9.627 us** |   **8.535 us** |   **603.2 us** |  **0.55** |    **0.01** |    **1** | **13.6719** | **2.9297** |     **-** |   **86.6 KB** |
|         Optimized |  Clr |     Clr |          20 |   True |   Array |   745.1 us | 14.521 us |  18.881 us |   746.0 us |  0.69 |    0.02 |    2 | 21.4844 | 3.9063 |     - | 134.15 KB |
|           Default |  Clr |     Clr |          20 |   True |   Array | 1,091.5 us | 11.568 us |  10.821 us | 1,091.6 us |  1.00 |    0.00 |    3 | 17.5781 | 5.8594 |     - | 111.16 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |   True |   Array |   418.1 us |  3.280 us |   3.069 us |   418.4 us |  0.44 |    0.01 |    1 |  9.7656 | 2.4414 |     - |  60.34 KB |
|         Optimized | Core |    Core |          20 |   True |   Array |   514.4 us |  4.445 us |   4.158 us |   513.8 us |  0.54 |    0.01 |    2 | 16.6016 | 2.9297 |     - | 107.58 KB |
|           Default | Core |    Core |          20 |   True |   Array |   945.1 us | 11.361 us |   9.487 us |   947.3 us |  1.00 |    0.00 |    3 | 11.7188 | 3.9063 |     - |  77.48 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |   **True** |  **ROList** |   **817.4 us** | **12.782 us** |  **11.956 us** |   **813.6 us** |  **0.69** |    **0.01** |    **1** | **15.6250** | **4.8828** |     **-** |  **97.61 KB** |
|         Optimized |  Clr |     Clr |          20 |   True |  ROList |   960.5 us |  7.516 us |   7.030 us |   960.2 us |  0.81 |    0.01 |    2 | 23.4375 | 7.8125 |     - | 144.48 KB |
|           Default |  Clr |     Clr |          20 |   True |  ROList | 1,182.9 us | 22.099 us |  20.672 us | 1,179.1 us |  1.00 |    0.00 |    3 | 19.5313 | 5.8594 |     - | 121.54 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |   True |  ROList | 1,208.1 us | 19.015 us |  17.787 us | 1,205.9 us |  0.72 |    0.02 |    1 | 11.7188 | 3.9063 |     - |  75.08 KB |
|         Optimized | Core |    Core |          20 |   True |  ROList | 1,318.6 us | 24.968 us |  23.355 us | 1,314.9 us |  0.79 |    0.02 |    2 | 19.5313 | 5.8594 |     - | 122.23 KB |
|           Default | Core |    Core |          20 |   True |  ROList | 1,673.9 us | 32.947 us |  27.513 us | 1,680.9 us |  1.00 |    0.00 |    3 | 13.6719 | 5.8594 |     - |  91.47 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| **OptimizedHeapless** |  **Clr** |     **Clr** |          **20** |   **True** | **ROArray** |   **732.3 us** |  **7.806 us** |   **6.920 us** |   **732.8 us** |  **0.67** |    **0.01** |    **1** | **15.6250** | **5.8594** |     **-** | **100.78 KB** |
|         Optimized |  Clr |     Clr |          20 |   True | ROArray |   864.6 us |  5.357 us |   5.011 us |   864.3 us |  0.79 |    0.01 |    2 | 23.4375 | 7.8125 |     - | 147.67 KB |
|           Default |  Clr |     Clr |          20 |   True | ROArray | 1,090.1 us | 14.512 us |  13.575 us | 1,093.6 us |  1.00 |    0.00 |    3 | 19.5313 | 5.8594 |     - | 124.87 KB |
|                   |      |         |             |        |         |            |           |            |            |       |         |      |         |        |       |           |
| OptimizedHeapless | Core |    Core |          20 |   True | ROArray | 1,100.9 us | 20.419 us |  18.101 us | 1,100.4 us |  0.71 |    0.02 |    1 | 11.7188 | 3.9063 |     - |  78.45 KB |
|         Optimized | Core |    Core |          20 |   True | ROArray | 1,182.3 us | 21.357 us |  19.977 us | 1,178.5 us |  0.77 |    0.03 |    2 | 19.5313 | 5.8594 |     - | 125.77 KB |
|           Default | Core |    Core |          20 |   True | ROArray | 1,516.8 us | 29.391 us |  47.460 us | 1,503.1 us |  1.00 |    0.00 |    3 | 13.6719 | 5.8594 |     - |  94.76 KB |
